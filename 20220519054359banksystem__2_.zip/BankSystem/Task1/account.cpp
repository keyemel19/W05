#include<iostream>
#include<string>
#include<stdexcept>
#include"account.h"
#include<bits/stdc++.h>
#include <list>

account::accNode::accNode(int id, string name, float balance)
{
accID=id;
accName=name;
accBalance=balance;
}
void account::displayMenu()
{
 cout<<"Account Menu:"<<"\n";
 cout<<"0. Quit Program"<<"\n";
 cout<<"1. Display Account Information"<<"\n";
 cout<<"2. Add a deposit to an account"<<"\n";
 cout<<"3. Withdraw from an account"<<"\n";
 cout<<"4. Add new account"<<"\n";
 cout<<"5. Find account by ID"<<"\n";
 cout<<"Your choice: ";
}

void account::addAccount(string name, float balance)
{
int id=acc.size();
	while(true)
	{
		if(findAccountById(id)==NULL)
		{
			break;
		}
     id++;
	}
accNode* tempAcc=new accNode(id, name, balance);
acc.push_back(tempAcc);
cout<<"Your Account ID: "<<id;
}
void account::printAccount(accNode* it)
{
	cout<<"Account ID: "<<(it)->accID<<" Name: "<<(it)->accName<<" Balance: "<<(it)->accBalance<<"\n";
}
void account::displayAccount()
{
	list<account::accNode*>::iterator it;
	if(acc.size()==0)
	{
		cout<<"No Account Found"<<"\n";
	}
		for(it=acc.begin();it!=acc.end();++it)
			printAccount((*it));
}
account::accNode* account::findAccountById(int id)
{
	list<account::accNode*>::iterator it;
	for(it=acc.begin();it!=acc.end();++it)
		if((*it)->accID==id)
			{
			return (*it);
			}
	return NULL;
}
void account::addDeposit(accNode* deposit)
{
float addBalance;
cout<<"Found account: "<<" Account ID: "<<deposit->accID<<" Name: "<<deposit->accName<<" Balance: "<<deposit->accBalance<<"\n";
cout<<"Amount to deposit: ";
cin>>addBalance;
deposit->accBalance=deposit->accBalance+addBalance;
cout<<"New Balance: "<<" Account ID: "<<deposit->accID<<" Name: "<<deposit->accName<<" Balance: "<<deposit->accBalance<<"\n";
}

void account::withdrawBalance(accNode* withdraw)
{
float balance;
cout<<"Found account: "<<" Account ID: "<<withdraw->accID<<" Name: "<<withdraw->accName<<" Balance: "<<withdraw->accBalance<<"\n";
cout<<"Amount to deposit: ";
cin>>balance;
if (withdraw->accBalance-balance>0)
{
	withdraw->accBalance=withdraw->accBalance-balance;
}
else
{
	withdraw->accBalance=0;
}

cout<<"New Balance: "<<" Account ID: "<<withdraw->accID<<" Name: "<<withdraw->accName<<" Balance: "<<withdraw->accBalance<<"\n";
}


