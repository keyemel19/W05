/*
 * account.h
 *
 *  Created on: 17-May-2022
 *      Author: LearningSector
 */

#include<iostream>
#include<string>
#include<list>
using namespace std;

#ifndef ACCOUNT_H_
#define ACCOUNT_H_


class account
{
private:
	struct accNode
	{
		int accID;
		string accName;
		float accBalance;

		accNode(int id, string name, float balance);
	};
	list<accNode*> acc;

public:

	void displayMenu();
	void printAccount(accNode* it);
	void addAccount(string name, float balance);

	accNode* findAccountById(int id);
	void displayAccount();

	void addDeposit(accNode* deposit);

	void withdrawBalance(accNode* withdraw);
};


#endif /* ACCOUNT_H_ */
