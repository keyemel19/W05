/*
 * account.h
 *
 *  Created on: 17-May-2022
 *      Author: LearningSector
 */

#include<iostream>
#include<string>
#include<list>
using namespace std;

#ifndef ACCOUNT_H_
#define ACCOUNT_H_


class account
{
private:
	struct accNode
	{
		int accID;
		string accName;
		float accBalance;

		accNode(int id, string name, float balance);
	};
	int ref_value;
	float ref_per;
	list<accNode*> acc;

public:
    account();
	void displayMenu();
	void printAccount(accNode* it);
	void addAccount(string name, float balance);
	accNode* findAccountById(int id);
	void displayAccount();
    void totalBalance();
	void addDeposit(accNode* deposit);
    bool matchedId(accNode* it);
    float sumBalance(int sum, accNode* it2);
    void removeAccount(int id);
	void withdrawBalance(accNode* withdraw);
	void calculateDividend(int per);
	accNode* findTransform(accNode* per);
	void findDividend(int val);
};


#endif /* ACCOUNT_H_ */
